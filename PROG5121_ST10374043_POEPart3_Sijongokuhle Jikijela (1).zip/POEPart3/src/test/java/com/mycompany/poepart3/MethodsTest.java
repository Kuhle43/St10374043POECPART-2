
package com.mycompany.poepart3;

import org.junit.jupiter.api.Test;

/**
 *
 * @author Sijongokuhle Jikijela
 */
public class MethodsTest {
    
    public MethodsTest() {
    }

    @Test
    public void testDisplayTaskDone() {
    String[]Developer={"Mike Smith","Edward Harrison","Samantha Paulson","Glenda Oberholzer"};   
    String[]TaskName ={"Create Login","Create Add Features","Create Reports","Add Arrays"};
    String[]Status ={"To Do","Doing","Done","To Do"};
    int[]duration ={5,8,2,11};
    Methods.developer=Developer;
    Methods.tasksDuration=duration;
    Methods.taskNames=TaskName;
    Methods.taskStatus=Status; 
    Methods.displayTaskDone();        
    }

    @Test
    public void testLongestTaskDuration() {
    String[]Developer={"Mike Smith","Edward Harrison","Samantha Paulson","Glenda Oberholzer"};
    int[]duration ={5,8,2,11};
    Methods.developer =Developer;
    Methods.tasksDuration=duration;
    Methods.longestTaskDuration();        
    }

    @Test
    public void testSearchForTask() {
    String[]Developer={"Mike Smith","Edward Harrison","Samantha Paulson","Glenda Oberholzer"};   
    String[]TaskName ={"Create Login","Create Add Features","Create Reports","Add Arrays"};
    String[]Status ={"To Do","Doing","Done","To Do"};
    int[]duration ={5,8,2,11};
    Methods.developer=Developer;
    Methods.tasksDuration=duration;
    Methods.taskNames=TaskName;
    Methods.taskStatus=Status; 
    Methods.searchForTask();        
    }

    @Test
    public void testDeveloperTasks() {
    String[]Developer={"Mike Smith","Edward Harrison","Samantha Paulson","Glenda Oberholzer"};   
    String[]TaskName ={"Create Login","Create Add Features","Create Reports","Add Arrays"};
    String[]Status ={"To Do","Doing","Done","To Do"};
    int[]duration ={5,8,2,11};
    Methods.developer=Developer;
    Methods.tasksDuration=duration;
    Methods.taskNames=TaskName;
    Methods.taskStatus=Status;
    Methods.developerTasks();        
    }

    @Test
    public void testDeleteTask() {
    String[]Developer={"Mike Smith","Edward Harrison","Samantha Paulson","Glenda Oberholzer"};   
    String[]TaskName ={"Create Login","Create Add Features","Create Reports","Add Arrays"};
    String[]Status ={"To Do","Doing","Done","To Do"};
    int[]duration ={5,8,2,11};
    int[] taskNumber={1,2,3,4};
    String[] Descriptions={"Create a login.","Create a add feature.","Create reports.","Add elements to the array"};
    String[]taskID={"CR:"+1+":IKE","CR:"+2+":ARD","CR:"+3+":SON","AD:"+4+":NDA"};
    Methods.taskNumbers=taskNumber;
    Methods.IDs=taskID;
    Methods.developer=Developer;
    Methods.tasksDuration=duration;
    Methods.taskNames=TaskName;
    Methods.taskStatus=Status;
    Methods.descriptions=Descriptions;
    Methods.deleteTask();
    Methods.displayTaskReport();        
    }

    @Test
    public void testDisplayTaskReport() {
    String[]Developer={"Mike Smith","Edward Harrison","Samantha Paulson","Glenda Oberholzer"};   
    String[]TaskName ={"Create Login","Create Add Features","Create Reports","Add Arrays"};
    String[]Status ={"To Do","Doing","Done","To Do"};
    int[]duration ={5,8,2,11};
    int[] taskNumber={1,2,3,4};
    String[] Descriptions={"Create a login.","Create a add feature.","Create reports.","Add elements to the array"};
    String[]taskID={"CR:"+1+":IKE","CR:"+2+":ARD","CR:"+3+":SON","AD:"+4+":NDA"};
    Methods.taskNumbers=taskNumber;
    Methods.IDs=taskID;
    Methods.developer=Developer;
    Methods.tasksDuration=duration;
    Methods.taskNames=TaskName;
    Methods.taskStatus=Status;
    Methods.descriptions=Descriptions;
    Methods.displayTaskReport();         
    }
    
}
