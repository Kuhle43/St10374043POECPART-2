
package com.mycompany.poepart3;

import javax.swing.JOptionPane;

/**
 *
 * @author Sijongokuhle Jikijela
 */
public class Methods {
    
    public static String[]IDs;
    public static String[]taskNames;
    public static int[]taskNumbers;
    public static String[]developer;
    public static String[]descriptions;
    public static String[]taskStatus;
    public static int[]tasksDuration;
    
public static boolean checkDescription(String input){
    int testLength;
    testLength = input.length();
    boolean lengthTrueOrFalse ;
 
    if (testLength > 50){
        JOptionPane.showMessageDialog(null,"Please enter a task description with less than 50 characters", "Incorrect",0);        
        lengthTrueOrFalse = false;
    }else {
        lengthTrueOrFalse = true;
    }
return lengthTrueOrFalse;
}   
public static String taskId(String taskName, int tasknumber, String devName){
    String taskID;
    String theFirstTwo = taskName.substring(0,2);
    String theLastThree = devName.substring(devName.length()- 3);
    taskID = theFirstTwo.toUpperCase()+":"+tasknumber+":"+theLastThree.toUpperCase();
    JOptionPane.showMessageDialog(null,"This is the taskID: "+taskID,"TaskID",1);    
return taskID;
}
public static String printTaskDetails(String status,int taskNumber,String TaskName, String taskDescription, String ID, double estimateDuration,int addnumofTasks){
    String printTaskDetails ="";
    String numTaskNumber = String.valueOf(taskNumber);
    String estimate = String.valueOf(estimateDuration);
    JOptionPane.showMessageDialog(null,"Task Status: "+status+"\n"+"Task number: "+numTaskNumber+"\n"+"Task name: "+TaskName+"\n"+"Task Description: "+taskDescription+"\n"+"Task ID: "+ID+"\n"+"Duration: "+estimate+"hrs"+"\n","Task Details ",1);
return printTaskDetails;
}
public static String taskStatus(){
String option;
String TaskOption = "";
option = JOptionPane.showInputDialog(null, """
                                           Please select the following options: 
                                           1. To Do
                                           2. Doing
                                           3. Done
                                           Please enter the choice you selected: ""","Task Status", 1);

    switch(option){
            case "1" -> TaskOption = "To Do"; 
            case "2" -> TaskOption = "Doing";
            case "3" -> TaskOption = "Done";
            default -> {
                JOptionPane.showMessageDialog(null,"Please enter either: To Do, Done or Doing", "Incorrect User Input",0);
                TaskOption = "To Do";
            }          
        }
    return TaskOption;
}
public static int returnTotalHours(int hour){
    JOptionPane.showMessageDialog(null,"This is the total hours for all your tasks "+hour,"Total Hours",1);    
return hour;
}
public static void displayTaskDone(){
    
       for(int i = 0; i < taskStatus.length; i++){
            if(taskStatus[i].equals("Done")){
            JOptionPane.showMessageDialog(null,"Developer Details: "+developer[i]+"\nTask Name : "+taskNames[i]+"\nTask Duration : "+tasksDuration[i]+"hrs"+"\nTask Status: "+taskStatus[i],"Task Status",1);
            }
        }
} 

public static void longestTaskDuration(){
 
   int longestTask = tasksDuration[0];
   int subScript = 0;        
    for(int i = 0; i < tasksDuration.length; i++){
         if(longestTask < tasksDuration[i]){
            longestTask= tasksDuration[i];
            subScript=i;    
            }
    }
    JOptionPane.showMessageDialog(null, "Developer Details: "+developer[subScript]+ "\nTask Duration: "+longestTask+"hrs","Task Longest Duration",1);    
}

public static void searchForTask(){
    String nameOfTask;  
    nameOfTask = JOptionPane.showInputDialog(null, "Please enter the name of Task you are searching for: ", "Task assigned to developer", 1);
        for(int i = 0; i < taskNames.length; i++){
            if(taskNames[i].equalsIgnoreCase(nameOfTask)){
            JOptionPane.showMessageDialog(null,"Task Name : "+developer[i]+"\nTask Status: "+taskStatus[i],"Developer Task",1);
            }
        }
    } 
public static void developerTasks(){
    String devTask;
    devTask = JOptionPane.showInputDialog(null, "Please enter the full name of the developer: ", "Task assigned to developer", 1);
        for(int i = 0; i < developer.length; i++){
           if(developer[i].equalsIgnoreCase(devTask)){
            JOptionPane.showMessageDialog(null,"Developer Details : "+developer[i]+"\nTask Name: "+taskNames[i]+"\nTask Status: "+taskStatus[i],"Developer Task",1);
           }
        }
}

   public static void deleteTask(){
    String nameOfTask;
    int indexLess = 0;
    String[]newTaskName;
    int[]newTaskNumber;
    String[]newdescription;
    String[]newDeveloper;
    int[]newDuration;
    String[]newID;
    String[]newStatus;
    newID = new String[IDs.length-1];
    newStatus = new String[taskStatus.length-1];
    newDuration= new int[tasksDuration.length-1];
    newTaskName = new String[taskNames.length-1];
    newTaskNumber = new int[taskNumbers.length-1];
    newDeveloper= new String[developer.length-1];       
    newdescription = new String[descriptions.length-1];
    
    nameOfTask = JOptionPane.showInputDialog(null, "Please write the name of the Task you want to delete.", "Delete a Task", 2);
    for(int i = 0; i < taskNames.length; i++){

        if(!taskNames[i].equalsIgnoreCase(nameOfTask)){
            newTaskName[indexLess] =taskNames[i];
            newTaskNumber[indexLess] =taskNumbers[i];
            newdescription[indexLess] =descriptions[i];
            newDeveloper[indexLess] =developer[i];
            newDuration[indexLess] =tasksDuration[i];
            newID[indexLess] =IDs[i];
            newStatus[indexLess] =taskStatus[i];
            indexLess++;
        }
    }
    JOptionPane.showMessageDialog(null, "The Task has been deleted", "Successfully Deleted", 1);
    taskNames=newTaskName; 
    taskNumbers=newTaskNumber;
    descriptions=newdescription;
    developer=newDeveloper;
    tasksDuration=newDuration;
    IDs=newID;
    taskStatus=newStatus;
}

   public static void displayTaskReport(){
        
       for(int i = 0; i < taskNames.length; i++){      
        JOptionPane.showMessageDialog(null,"Task Name: "+taskNames[i]+"\nTask number: "+taskNumbers[i]+
            "\nTask Description: "+descriptions[i]+"\nDeveloper Details: "+developer[i]+"\nTask Duration: "+tasksDuration[i]+"hrs"+
            "\nTask ID: "+IDs[i]+"\nTask Status: "+taskStatus[i],"Task Report",1);
        }
    }
}
