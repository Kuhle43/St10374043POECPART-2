

package com.mycompany.poepart3;

import javax.swing.JOptionPane;

/**
 * @author Sijongokuhle Jikijela
 */
public class POEPart3 {
      
public static void main(String[] args) {
    
        String options;
        String numberOfTasks;
        String Status;
        String ID;       
        String TaskName;
        String choice;
        String taskDescription;
        String FullName;
        String FirstName;
        String LastName;
        String expected;
        String[] taskNames;
        String[] description;
        String[] developer;
        String[]taskStatus;
        String[]IDs;
        int Hours = 0;
        int numOfTasks;
        int expectedHour;
        int taskNumber = 0;
        int[] taskNumbers;
        int[] tasksDuration;
do{    
options = JOptionPane.showInputDialog(null, """
                                            Please select the following options: 
                                            Option 1) Add tasks 
                                            Option 2) Show report
                                            Option 3) Quit
                                            Please enter the option of your choice: ""","Welcome to EasyKanban",1);
    switch(options){
        case "1" -> {
            numberOfTasks = JOptionPane.showInputDialog(null,"Please enter the number of tasks you wish to set: ","Add tasks",1);
            numOfTasks = Integer.parseInt(numberOfTasks);
            
            taskNumbers = new int[numOfTasks];
            taskNames = new String[numOfTasks];
            description = new String[numOfTasks];
            developer = new String[numOfTasks];
            tasksDuration = new int[numOfTasks];
            taskStatus = new String[numOfTasks];
            IDs = new String[numOfTasks];
            
            for(int i = 0; i < numOfTasks;i++){
                
                TaskName = JOptionPane.showInputDialog(null,"Please enter the Task Name: ","Task Name",1);
                taskNames[i] = TaskName;
                taskNumber++;
                taskNumbers[i]= taskNumber;
                
                taskDescription = JOptionPane.showInputDialog(null,"Please enter the Task Description, should not exceed over 50 characters: ","Task Description",1);
                
                description[i] = taskDescription;
                
                FirstName = JOptionPane.showInputDialog(null,"Please enter your First name: ","Developer Details",1);
                LastName = JOptionPane.showInputDialog(null,"Please enter your Last name: ","Developer Details",1);
                FullName = FirstName+" "+LastName;
                developer[i]= FullName;
                
                expected = JOptionPane.showInputDialog(null,"Please enter your estimated duration for the task in hours: ","Task Duration",1);
                expectedHour= Integer.parseInt(expected);
                tasksDuration[i]= expectedHour;
                
                ID =  Methods.taskId(TaskName, taskNumber, FullName);
                IDs[i] = ID;
                
                Status =  Methods.taskStatus();
                taskStatus[i]= Status;
                
                Methods.printTaskDetails(Status, taskNumber, TaskName, taskDescription, ID, expectedHour, numOfTasks);
                
                Hours = Hours + expectedHour;
                
               }
                Methods.taskNames= taskNames;
                Methods.taskNumbers= taskNumbers;
                Methods.descriptions= description;
                Methods.developer= developer;
                Methods.tasksDuration= tasksDuration;
                Methods.IDs= IDs;
                Methods.taskStatus= taskStatus;
                
                Methods.returnTotalHours(Hours);
                }
            case "2" -> {
                do{
                    choice = JOptionPane.showInputDialog(null, """
                                                               Please select the following options:
                                                               1. Display all the tasks with the status of Done.
                                                               2. Display the longest task duration.
                                                               3. Search for a Task.
                                                               4. Search for Tasks assigned to a developer
                                                               5. Delete a Task
                                                               6. Display a report of all captured Tasks.
                                                               7. Go back to the Main Menu""","Show Report", 1);
                    
                    switch(choice){
                        
                        case "1" -> Methods.displayTaskDone();
                        case "2" -> Methods.longestTaskDuration();
                        case "3" -> Methods.searchForTask();
                        case "4" -> Methods.developerTasks();
                        case "5" -> Methods.deleteTask();
                        case "6" -> Methods.displayTaskReport();
                        case "7" -> {
                        }
                            
                    } 
                }while(!choice.equals("7"));
                }
            case "3" -> System.exit(0);
            default -> JOptionPane.showMessageDialog(null,"Enter either 1,2 or 3","Wrong input",0);          
        }
    }while(!options.equals("3"));

    }
}
